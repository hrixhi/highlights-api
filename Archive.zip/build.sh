#!/bin/bash
yarn
yarn build